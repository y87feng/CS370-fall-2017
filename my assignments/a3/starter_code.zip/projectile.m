% function dzdt = projectile(t, z)
%
function dzdt = projectile(t, z)

    dzdt = [ 0 ; 0 ; 0 ; 0 ];

