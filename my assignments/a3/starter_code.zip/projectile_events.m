% function value = projectile_events(t, z)
%
function value = projectile_events(t, z)

    value = 0;
    
