%% filter_audio.m

%Load some audio
blah = importdata('recording.wav');
f = blah.data;        % Rename the variables to our liking
Omega = blah.fs;      % Sampling rate (samples per second, or Hz)
clear blah;           % We don't need this anymore

% Derive some useful variables
N = length(f);             % Number of samples
L = N / Omega;             % Clip duration in seconds
t = ( 0:(N-1) )' * L/N;    % Time axis labels
omega = ifftshift( (-N/2):(N/2 - 1) )' / L;

% Plot time domain signal f
figure(1);
plot(f); title('Sound');
xlabel('Time (seconds)');
ylabel('Amplitude');


%% Listen to the sound

% If you are running Matlab locally, you can play the sound using
%   sound(f, Omega);
% You can also save a wav file and download and listen to it.
audiowrite('sound_file.wav', real(f), Omega);


%% === YOUR CODE HERE ===

%% (a)


%% (b)


%% (c)


%% (d)


