% unlock.m script

% Display grid of 16 circles
[gx, gy] = meshgrid([0 20 40 60], [0 20 40 60]);
plot(gx(:), gy(:),'ko', 'MarkerSize',10);
hold on; % don't erase plot on next plot command


% --- YOUR CODE HERE ---

